package edu.project.vyakyansoppingcart.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import edu.project.vyakhyansoppingcart_backend.dao.CatogaryDAO;
import edu.project.vyakhyansoppingcart_backend.dao.ProductDAO;
import edu.project.vyakhyansoppingcart_backend.dto.Catogary;
import edu.project.vyakhyansoppingcart_backend.dto.Product;
import edu.project.vyakyansoppingcart.exception.ProductNotFoundException;

@Controller
public class PageController {

	private static final Logger logger = LoggerFactory.getLogger(PageController.class);
	
	@Autowired
	private CatogaryDAO catogaryDAO;

	@Autowired
	private ProductDAO productDAO;

	@RequestMapping(value = { "/", "/home", "/index" })
	public ModelAndView home() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "Home");
		mv.addObject("Catogaries", catogaryDAO.list());
		mv.addObject("UserClickHome", true);
		logger.info("Inside PageController Home Method - INFO");
		logger.debug("Inside PageController Home Method - DEBUG");
		return mv;
	}

	@RequestMapping(value = "about")
	public ModelAndView about() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "About Us");
		mv.addObject("UserClickAbout", true);
		return mv;
	}

	@RequestMapping(value = "contact")
	public ModelAndView contact() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "Contact Us");
		mv.addObject("UserClickContact", true);
		return mv;
	}

	@RequestMapping(value = "show/all/products")
	public ModelAndView allCatogaries() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("Catogaries", catogaryDAO.list());
		mv.addObject("title", "All Catogaries");
		mv.addObject("UserClickAllCatogaries", true);
		return mv;
	}

	@RequestMapping(value = "show/catogary/{id}/products")
	public ModelAndView getCatogary(@PathVariable("id") long id) {

		Catogary catogary = null;
		catogary = catogaryDAO.findById(id);

		ModelAndView mv = new ModelAndView("page");
		mv.addObject("Catogaries", catogaryDAO.list());
		mv.addObject("catogary", catogary);
		mv.addObject("title", catogary.getName());
		mv.addObject("UserClickOnCatogary", true);
		return mv;
	}

	@RequestMapping(value = "show/{id}/product")
	public ModelAndView getProduct(@PathVariable("id") long id) throws ProductNotFoundException{

		ModelAndView mv = new ModelAndView("page");
		Product product = productDAO.getById(id);
		
		if(product==null) throw new ProductNotFoundException();	
		
		product.setView(product.getView() + 1);
		productDAO.update(product);

		mv.addObject("", product.getName());
		mv.addObject("product", product);
		mv.addObject("UserclickOnShowProduct", true);
		return mv;
	}

}
