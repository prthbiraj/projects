package edu.project.vyakyansoppingcart.exception;

public class ProductNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	private String massage;

	public ProductNotFoundException() {
		this("Product not available!");
	}

	public ProductNotFoundException(String massage) {
		this.massage = System.currentTimeMillis() + " : " + massage;
	}

	public String getMassage() {
		return massage;
	}

}
