package edu.project.vyakyansoppingcart.util;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

public class FileUploadUtility {

	private static final String ABC_PATH = "E:\\Live Projects\\Online Shopping Application\\vyakyansoppingcart\\src\\main\\webapp\\assets\\images\\";
	private static String REAL_PATH= "";
	private static final Logger LOGGER = LoggerFactory.getLogger(FileUploadUtility.class);
	
	public static void uploadFile(HttpServletRequest request, MultipartFile file, String code) {
		
		//get real path
		REAL_PATH = request.getSession().getServletContext().getRealPath("/assets/images/");
		LOGGER.info(REAL_PATH);
		
		//check directory exist
		
		if(!new File(ABC_PATH).exists()) {
			// Make Directory
			new File(ABC_PATH).mkdirs();
		}
		
		if(!new File(REAL_PATH).exists()) {
			// Make Directory
			new File(REAL_PATH).mkdirs();
		}
		
		try {
			//upload on server
			file.transferTo(new File(REAL_PATH + code + ".jpg"));
			
			//upload on project directory
			file.transferTo(new File(ABC_PATH + code + ".jpg"));
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}
}
