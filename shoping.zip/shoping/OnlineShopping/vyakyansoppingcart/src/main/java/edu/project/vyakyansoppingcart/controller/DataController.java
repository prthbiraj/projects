package edu.project.vyakyansoppingcart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import edu.project.vyakhyansoppingcart_backend.dao.ProductDAO;
import edu.project.vyakhyansoppingcart_backend.dto.Product;

@Controller
@RequestMapping("json/data")
public class DataController {

	@Autowired
	private ProductDAO productDAO;
	
	
	@RequestMapping("/all/products")
	@ResponseBody
	public ResponseEntity<List<Product>> getAll(){
		List<Product> products = productDAO.listActiveProduct();		
		if(products.isEmpty()) {
			return new ResponseEntity<List<Product>>(HttpStatus.NOT_FOUND);
		}		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@RequestMapping("/category/{id}/products")
	@ResponseBody
	public ResponseEntity<List<Product>> getById(@PathVariable("id") long id){
		List<Product> products = productDAO.listActiveProductByCatagoryId(id);		
		if(products.isEmpty()) {
			return new ResponseEntity<List<Product>>(HttpStatus.NOT_FOUND);
		}		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	
}
