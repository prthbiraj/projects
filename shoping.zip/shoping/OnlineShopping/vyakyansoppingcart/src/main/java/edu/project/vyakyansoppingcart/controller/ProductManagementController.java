package edu.project.vyakyansoppingcart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.project.vyakhyansoppingcart_backend.dao.CatogaryDAO;
import edu.project.vyakhyansoppingcart_backend.dao.ProductDAO;
import edu.project.vyakhyansoppingcart_backend.dto.Catogary;
import edu.project.vyakhyansoppingcart_backend.dto.Product;
import edu.project.vyakyansoppingcart.util.FileUploadUtility;

@Controller
@RequestMapping("/manage")
public class ProductManagementController {

	@Autowired
	private CatogaryDAO categoryDAO;
	
	@Autowired
	private ProductDAO productDAO;
	
	private static final Logger logger = LoggerFactory.getLogger(ProductManagementController.class);
	
	@RequestMapping(value="/products", method=RequestMethod.GET)
	public ModelAndView showManageProducts(@RequestParam (name="complitionflag", required=false) String flag) {		
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title", "Manage Products");
		mv.addObject("UserClickOnManageProducts", true);
		
		// New Product
		Product newProduct = new Product();
		newProduct.setSupplierId(1);
		newProduct.setActive(true);
		mv.addObject("product", newProduct);
		
		if(flag!= null) {
			if(flag.equals("product")) {
				mv.addObject("massagetitle", "Congratulations...");
				mv.addObject("massage", "Product Added Successfully!!!" );
				
			}
		}
		return mv;
		
	}
	
	
	@ModelAttribute("categories")
	public List<Catogary> getCategories(){
		return categoryDAO.list();
	}
	
	//Handling product submission
	@RequestMapping(value="/products", method=RequestMethod.POST)
	public String handleProductSubmission(@Valid @ModelAttribute ("product") Product mProduct, BindingResult result,
			Model model, HttpServletRequest request) {
		
		//check error
		if(result.hasErrors()) {
			model.addAttribute("title", "Manage Products");
			model.addAttribute("UserClickOnManageProducts", true);
			model.addAttribute("massage", "Validaion error occured..." );
			return "page";
		}
			
		
		//create new product
		logger.debug(mProduct.toString());
		productDAO.add(mProduct);
		
		//upload file
		
		if(!mProduct.getFile().getOriginalFilename().equals("")) {
			FileUploadUtility.uploadFile(request, mProduct.getFile(), mProduct.getCode());
		}
		
		return "redirect:/manage/products?complitionflag=product";
	}
	
	
}
