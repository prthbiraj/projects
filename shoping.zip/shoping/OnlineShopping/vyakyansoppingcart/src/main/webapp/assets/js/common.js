$(function() {

	switch (menu) {

	case "Home":
		$("#home").addClass("active");
		break;

	case "About Us":
		$("#about").addClass("active");
		break;

	case "Contact Us":
		$("#contact").addClass("active");
		break;

	case "All Catogaries":
		$("#products").addClass("active");
		break;
		
	case "Manage Products":
		$("#manageproducts").addClass("active");
		break;

	default:
		$("#c_" + menu).addClass("active");
		console.log("#c_" + menu)
		$("#products").addClass("active");
		break;
	}
	
	
	/*
	 * var products = [ [ '1', 'A' ], [ '2', 'B' ], [ '3', 'C' ], [ '4', 'D' ], [
	 * '5', 'E' ], [ '6', 'F' ], [ '7', 'G' ] ];
	 */

	var $table = $('#productListTable');

	var jsonUrl = '';

	if (window.categoryId == '') {
		jsonUrl = window.contextRoot + '/json/data/all/products';
	} else {
		jsonUrl = window.contextRoot + '/json/data/category/' + window.categoryId
				+ '/products';
	}

	if ($table.length) {
		console.log("Insight table");
		$table
				.DataTable({
					lengthMenu : [ [ 3, 5, 10, -1 ],
							[ '3 Records', '5 Records', '10 Records', 'All' ] ],
					pageLength : 5,
					ajax : {
						url : jsonUrl,
						dataSrc : ''
					},
					columns : [

							{
								data : 'code',
								mRender : function(data, type, row) {
									return '<img src="' + window.contextRoot
											+ '/resources/images/' + data
											+ '.jpg" class="datatableimg"/>';
								}
							},
							{
								data : 'name'
							},

							{
								data : 'brand'
							},

							{
								data : 'unitPrice',
								mRender : function(data, type, row) {
									return '&#8377; ' + data;
								}
							},
							{
								data : 'quantity',
								mRender : function(data, type, row) {
									if (data < 1) {
										return '<span style="color: red;">Out Of Stock</span>';
									}
									return data;
								}
							},
							{
								data : 'id',
								bSortable : false,
								mRender : function(data, type, row) {
									var str = '';
									str += '<a href="'
											+ window.contextRoot
											+ '/show/'
											+ data
											+ '/product" class="btn btn-primary"><span class = "glyphicon glyphicon-eye-open" ></span></a> &#160;';
									if (row.quantity < 1) {
										str += '<a href="javascript:void(0)" class="btn btn-success disabled"><strike><span class = "glyphicon glyphicon-shopping-cart" ></span></strike></a>';

									} else {
										str += '<a href="'
												+ window.contextRoot
												+ '/card/add/'
												+ data
												+ '/product" class="btn btn-success"><span class = "glyphicon glyphicon-shopping-cart" ></span></a>';

									}

									return str;
								}
							} ]

				});

	}


	//close alert 

	var $alert = $('.alert');
	if($alert.length){
		setTimeout(function(){
			$alert.fadeOut('slow');
		}, 3000);
	}

});

