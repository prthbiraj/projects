package edu.project.vyakhyansoppingcart_backend.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import edu.project.vyakhyansoppingcart_backend.dao.ProductDAO;
import edu.project.vyakhyansoppingcart_backend.dto.Product;


@Repository("productDAO")
@Transactional
@SuppressWarnings({ "unchecked", "deprecation" })
public class ProductDAOImpl implements ProductDAO{

	@Autowired
	private SessionFactory sessionFactory;
 
	protected Session getSession() {
		return this.sessionFactory.getCurrentSession();
	}	
	
	@Override
	public List<Product> list() {

		return getSession().createCriteria(Product.class)
				.add(Restrictions.eqOrIsNull("active", true))
				.list();
	}

	@Override
	public Product getById(long id) {
		
		return getSession().get(Product.class, id);
	}

	@Override
	public boolean add(Product product) {
		getSession().persist(product);
		return true;
	}

	@Override
	public boolean update(Product product) {
		getSession().update(product);
		return true;
	}

	@Override
	public boolean delete(Product product) {
		product.setActive(false);
		getSession().update(product);
		return true;
	}

	@Override
	public List<Product> listActiveProduct() {
		
		return getSession().createCriteria(Product.class).add(Restrictions.eqOrIsNull("active", true))
				.list();
	}

	@Override
	public List<Product> listActiveProductByCatagoryId(long categoryId) {
		return getSession().createCriteria(Product.class).
				add(Restrictions.and(Restrictions.eqOrIsNull("active", true), 
						Restrictions.eqOrIsNull("categoryId", categoryId))).list();
	}

	@Override
	public List<Product> listActiveLatestProduct(int count) {
		return getSession().createCriteria(Product.class)
		.add(Restrictions.eqOrIsNull("active", true))
		.addOrder(Order.asc("id"))
		.setFirstResult(0)
		.setMaxResults(count)
		.list();	
		
	}

}
