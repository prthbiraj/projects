package edu.project.vyakhyansoppingcart_backend.dao;

import java.util.List;

import edu.project.vyakhyansoppingcart_backend.dto.Catogary;

public interface CatogaryDAO {

	List<Catogary> list();
	Catogary findById(long id);
	boolean add(Catogary catogary);
	boolean udate(Catogary catogary);
	boolean delete(Catogary catogary);
}
