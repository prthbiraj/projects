package edu.project.vyakhyansoppingcart_backend.dao;

import java.util.List;

import edu.project.vyakhyansoppingcart_backend.dto.Product;

public interface ProductDAO {

	List<Product> list();
	Product getById(long id);
	boolean add(Product product);
	boolean update(Product product);
	boolean delete(Product product);
	
	//Business Method
	List<Product> listActiveProduct();
	List<Product> listActiveProductByCatagoryId(long categoryId);
	List<Product> listActiveLatestProduct(int count);
}
