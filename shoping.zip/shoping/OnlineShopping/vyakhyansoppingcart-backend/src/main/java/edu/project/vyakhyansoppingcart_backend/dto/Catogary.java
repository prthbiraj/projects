package edu.project.vyakhyansoppingcart_backend.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="category")
public class Catogary {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private long id;
	@Column(name="name")
	private String name;
	@Column(name="description")
	private String description;
	@Column(name="image_url")
	private String imgPath;
	@Column(name="is_active")
	private boolean isActive;
	
	
	public Catogary() {
		super();
	}
	
	
	public Catogary(String name, String description, String imgPath, boolean isActive) {
		super();
		this.name = name;
		this.description = description;
		this.imgPath = imgPath;
		this.isActive = isActive;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImgPath() {
		return imgPath;
	}
	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	@Override
	public String toString() {
		return "Catogary [id=" + id + ", name=" + name + ", description=" + description + ", imgPath=" + imgPath
				+ ", isActive=" + isActive + "]";
	}
	
	
}
