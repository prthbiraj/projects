package edu.project.vyakhyansoppingcart_backend.daoimpl;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import edu.project.vyakhyansoppingcart_backend.dao.CatogaryDAO;
import edu.project.vyakhyansoppingcart_backend.dto.Catogary;



@Repository("catogaryDAO")
@Transactional
@SuppressWarnings({ "unchecked", "deprecation" })
public class CatogaryDAOImpl implements CatogaryDAO{

	
	@Autowired
	private SessionFactory sessionFactory;
 
	protected Session getSession() {
		return this.sessionFactory.getCurrentSession();
	}	
	
	
	@Override
	public List<Catogary> list() {		
		return getSession().createCriteria(Catogary.class)
				.add(Restrictions.eqOrIsNull("isActive", true)).list();
	}
	
	@Override
	public Catogary findById(long id) {		
		return getSession().get(Catogary.class, id);
	}

	@Override
	public boolean add(Catogary catogary) {
		getSession().persist(catogary);
		return true;
	}

	@Override
	public boolean udate(Catogary catogary) {
		getSession().update(catogary);
		return true;
	}

	@Override
	public boolean delete(Catogary catogary) {
		catogary.setActive(false);
		getSession().update(catogary);
		return true;
	}
	

}
