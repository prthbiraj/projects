package edu.project.vyakhyansoppingcart_backend.test;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import edu.project.vyakhyansoppingcart_backend.dao.ProductDAO;
import edu.project.vyakhyansoppingcart_backend.dto.Product;

public class VyakhyanShoppingProductTestCase {

	
	private static AnnotationConfigApplicationContext context;
	private static ProductDAO dao;
	private static Product product;
	
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("edu.project.vyakhyansoppingcart_backend");
		context.refresh();
		dao = (ProductDAO) context.getBean("productDAO");
	}
	
	@Test
	public void testProductCRUD() {
		
		//create
		
		product = new Product ("Iphone x", "Apple", "My Dream phone", 75000, 1, true, 3, 3, 0, 0);
		
		assertEquals("add product Success....", true, dao.add(product));
		
		//read
		//assertEquals("add product Success....", "Iphone x", dao.getById(33).getName());
		
		//update
		/*product =dao.getById(6);
		product.setDescription("This is one of the best phone available in the market right now!, after IphoneX");
		assertEquals("update product Success....", true, dao.update(product));
		*/
		//delete
		/*product =dao.getById(6);
		assertEquals("update product Success....", true, dao.delete(product));*/
		
		
		//all products
		//assertEquals("Get all products Success....", 5, dao.list().size());
		
		//product by Category Id
		//assertEquals("Get  product by Category Id Success....", 2, dao.listActiveProductByCatagoryId(1).size());
		
		
		//Latest Product
		assertEquals("GetLatest Product  Success....", 3, dao.listActiveLatestProduct(3).size());
	}
}
