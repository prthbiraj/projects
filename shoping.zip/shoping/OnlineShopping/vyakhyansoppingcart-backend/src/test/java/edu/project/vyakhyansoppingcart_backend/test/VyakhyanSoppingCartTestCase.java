package edu.project.vyakhyansoppingcart_backend.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import edu.project.vyakhyansoppingcart_backend.dao.CatogaryDAO;
import edu.project.vyakhyansoppingcart_backend.dto.Catogary;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

public class VyakhyanSoppingCartTestCase {

	private static AnnotationConfigApplicationContext context;
	private static CatogaryDAO dao;
	private static Catogary category;

	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("edu.project.vyakhyansoppingcart_backend");
		context.refresh();
		dao = (CatogaryDAO) context.getBean("catogaryDAO");
	}
	
	/*@Test
	public void testAddCatogary() {
		  
			category = new Catogary("Television", "Television Description", "cat1.png", true);		  
			assertEquals("Add Success....", true, dao.add(category));

	}*/
	
	@Test
	public void testCRUDCatogary() {
		  
		//insert 
		/*	category = new Catogary("Television", "Television Description", "cat1.png", true);		  
			assertEquals("Add Success....", true, dao.add(category));
			category = new Catogary("Mobile", "Mobile Description", "cat2.png", true);		  
			assertEquals("Add Success....", true, dao.add(category));
			category = new Catogary("LapTop", "LapTop Description", "cat3.png", true);		  
			assertEquals("Add Success....", true, dao.add(category));*/
			
		//read			
			assertEquals("Get Success....", 1, dao.findById(1).getId());
			
		//update
			/*category = dao.findById(1);
			category.setDescription("Updated description..");			
			assertEquals("Update Success....", true, dao.udate(category));*/
			
		//delete
			/*category = dao.findById(1);					
			assertEquals("Update Success....", true, dao.delete(category));*/
			
		//read all
			assertEquals("Get Success....", 2, dao.list().size());

	}
	
}
