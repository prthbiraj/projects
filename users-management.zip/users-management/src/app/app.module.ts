import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeModule } from './home/home.module';
import { CoreModule } from './core/core.module';
import { ContactComponent } from './contact/contact.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule } from '@angular/material';
import { TopicsComponent } from './topic/components/topics/topics.component';


@NgModule({
  declarations: [
    AppComponent,
    ContactComponent
  ],
  imports: [  
    CommonModule,
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    HomeModule,
    BrowserAnimationsModule,
    MatDialogModule
  ],
  exports:[],
  providers: [],
  bootstrap: [AppComponent]  
})
export class AppModule { }
