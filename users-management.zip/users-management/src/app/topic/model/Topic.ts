export const ELEMENT_DATA: Topic[] = [
    {
        id: 1, title: 'Angular', imgSrc: '/assets/img/angular-logo.svg', desc: `Learn one way to build applications 
    with Angular and reuse your code and abilities to 
    build apps for any deployment target. 
    For web, mobile web, native mobile.`},
    {
        id: 2, title: 'JAVA', imgSrc: '/assets/img/java-logo.svg', desc: `Java is powering the innovation behind our digital world. 
    Harness this potential with Java resources 
    for student coders, hobbyists, developers, and IT leaders.`},
    {
        id: 3, title: 'Spring', imgSrc: '/assets/img/spring-logo.svg', desc: `The Spring Framework provides a 
    comprehensive programming and configuration model for 
    modern Java-based enterprise applications - 
    on any kind of deployment platform.`},
    {
        id: 4, title: 'SQL', imgSrc: '/assets/img/sql-logo.svg', desc: `SQL is a standard language for storing, manipulating and retrieving data in databases.
    Our SQL tutorial will teach you how to use SQL in: Oracle and database.`},
    {
        id: 5, title: 'GIT', imgSrc: '/assets/img/github-logo.svg', desc: `Git is a free and open source distributed version control 
    system designed to handle everything from small to very large projects with 
    speed and efficiency.`},
    {
        id: 6, title: 'Hibernate', imgSrc: '/assets/img/hibernate-logo.svg', desc: `Hibernate ORM is an object-relational mapping tool for the 
    Java programming language. It provides a framework for mapping an 
    object-oriented domain model.`},
    {
        id: 7, title: 'TypeScript', imgSrc: '/assets/img/typescript-logo.svg', desc: `TypeScript is an open-source programming language developed 
    and maintained by Microsoft. It is a strict syntactical superset of JavaScript.`},
    {
        id: 8, title: 'Interview', imgSrc: '/assets/img/interview-logo.svg', desc: `Programming today is a race between software engineers 
    striving to build bigger and better idiot-proof programs, 
    and the Universe trying to produce bigger and better idiots.`}
];

export interface Topic {
    id: number;
    title: string;
    imgSrc: string;
    desc?: String;
}