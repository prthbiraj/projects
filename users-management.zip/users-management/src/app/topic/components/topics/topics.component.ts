import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DialogUtilService } from 'src/app/shared/services/dialog-util.service';
import { faEdit} from '@fortawesome/free-solid-svg-icons';
import { ELEMENT_DATA, Topic } from '../../model/Topic';
@Component({
  selector: 'app-topics',
  templateUrl: './topics.component.html',
  styleUrls: ['./topics.component.css']
})
export class TopicsComponent implements OnInit {

  faEdit = faEdit;
  topics:Topic[];
  constructor(private router:Router,
    private dialogUtilService:DialogUtilService) { }

  ngOnInit() {
    this.topics = ELEMENT_DATA;
  }

  addTopic(){
    let data = { type: "info", title: "Confirmation", msg: "Do you want to add topic?", okButtonText: "Ok" };
    let config = {width : "600px",disableClose : true,autoFocus: true, data:data}
    let dialogRef = this.dialogUtilService.showDialog(config);
    dialogRef.afterClosed().subscribe(result => {      
      if (result) {
        this.router.navigate([`/topics/new`]);
      }
    });
  }
}

