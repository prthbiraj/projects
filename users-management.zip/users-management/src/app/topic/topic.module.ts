import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TopicRoutingModule } from './topic-routing.module';
import { TopicsComponent } from './components/topics/topics.component';
import { AddTopicComponent } from './components/add-topic/add-topic.component';
import { UpdateTopicComponent } from './components/update-topic/update-topic.component';
import { RouterModule } from '@angular/router';
import { ConfirmationDialogComponent } from '../shared/components/confirmation-dialog/confirmation-dialog.component';
import { SharedModule } from '../shared/shared.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';


@NgModule({
  declarations: [TopicsComponent, AddTopicComponent, UpdateTopicComponent],
  imports: [
    CommonModule,
    SharedModule,
    TopicRoutingModule,
    FontAwesomeModule,
    RouterModule
  ],
  entryComponents: [ConfirmationDialogComponent]
})
export class TopicModule { }
