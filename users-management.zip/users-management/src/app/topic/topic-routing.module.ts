import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TopicsComponent } from './components/topics/topics.component';
import { AddTopicComponent } from './components/add-topic/add-topic.component';
import { UpdateTopicComponent } from './components/update-topic/update-topic.component';


const routes: Routes = [{
  path:'',
  component:TopicsComponent
},
{
  path:'new',
  component:AddTopicComponent
},
{
  path:':topicId',
  component:UpdateTopicComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TopicRoutingModule { }
