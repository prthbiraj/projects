import { NgModule } from "@angular/core";
import { ConfirmationDialogComponent } from './components/confirmation-dialog/confirmation-dialog.component';
import { MatDialogModule } from '@angular/material';
import { DialogUtilService } from './services/dialog-util.service';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ConfirmationSnackbarComponent } from './components/confirmation-snackbar/confirmation-snackbar.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { SnackbarUtilService } from './services/snackbar-util.service';

@NgModule({
    declarations:[ConfirmationDialogComponent, ConfirmationSnackbarComponent],
    imports:[MatDialogModule, CommonModule, FontAwesomeModule, MatSnackBarModule],
    exports:[ConfirmationDialogComponent, ConfirmationSnackbarComponent],
    providers:[DialogUtilService, SnackbarUtilService]
})
export class SharedModule{}