import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ConfirmationDialogComponent } from '../components/confirmation-dialog/confirmation-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class DialogUtilService {

  constructor(private dialog: MatDialog) { }

  showDialog(config){
    return this.dialog.open(ConfirmationDialogComponent, {
      width: config.width,
      disableClose : config.disableClose,
      autoFocus : config.autoFocus,
      data: config.data
    });
  }
}
