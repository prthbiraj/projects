import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { ConfirmationSnackbarComponent } from '../components/confirmation-snackbar/confirmation-snackbar.component';

@Injectable({
  providedIn: 'root'
})
export class SnackbarUtilService {


  constructor(public snackBar: MatSnackBar) { }

  openSnackBar(config) {
    return this.snackBar.openFromComponent(ConfirmationSnackbarComponent, {
      duration: config.duration,
      verticalPosition: config.verticalPosition,
      horizontalPosition:config.horizontalPosition,
      data:config.data
    });
  }  
}
