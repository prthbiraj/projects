import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog'
import { faInfoCircle, faExclamationTriangle, faTimes } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ConfirmationDialogComponent implements OnInit {
  isModalActive: boolean = false;
  faInfoCircle = faInfoCircle;
  faExclamationTriangle = faExclamationTriangle;
  faTimes = faTimes;

  constructor(private dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {

  }

  ngOnInit() {

  }

  close() {
    this.dialogRef.close();
  }

  ok() {
    this.dialogRef.close("Value");
  }

  toggleModal() {
    this.isModalActive = !this.isModalActive;
  }
}

export interface DialogData {
  type: string;
  title: string;
  msg: string;
  okButtonText: string;
}