import { NgModule } from "@angular/core";
import { HomeComponent } from './components/home.component';
import {MatCardModule} from '@angular/material/card';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
@NgModule({
    declarations:[HomeComponent],
    imports:[MatCardModule,
        CarouselModule,
        BrowserAnimationsModule],
    providers:[],
    exports:[HomeComponent]
})
export class HomeModule{
    
}