import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';import { SearchUserComponent } from './components/search-user/search-user.component';
import { CreateUserComponent } from './components/create-user/create-user.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
;


const routes: Routes = [
 {
     path:'',
     component:SearchUserComponent
 },
 {
     path:'new',
     component:CreateUserComponent
 },
 {
     path:':userId',
     component:EditUserComponent
 }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule { }
