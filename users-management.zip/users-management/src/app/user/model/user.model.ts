export const ELEMENT_DATA: User[] = [
	{
		"id" : 27952,
		"name" : "Francis S. Simpson",	
		"email" : "FrancisSSimpson@dayrep.com",			
		"contactNo" : 2568138835,
		"address":`2685 New Creek Road
		Huntsville, AL 35802`
	},
	{
		"id" : 43952,
		"name" : "Mary T. Ferrill",
		"email" : "MaryTFerrill@armyspy.com",		
		"contactNo" : 5308975718,
		"address":`3368 Maxwell Farm Road
		Chico, CA 95928`
	},
	{
		"id" : 19952,
		"name" : "Randall G. Cooper",
		"email" : "RandallGCooper@rhyta.com",		
		"contactNo" : 3183816988,
		"address":`3729 August Lane
		Monroe, LA 71201`
	},
	{
		"id" : 45952,
		"name" : "Wade J. Negrete",
		"email" : "SWadeJNegrete@teleworm.us",		
		"contactNo" : 7066768563,
		"address":`155 Radio Park Drive
		Rome, GA 30165`
	}
]


export class User {
  id: number;
  name: string;
  email: string;
  contactNo: number;
  address: string;
}
