import { NgModule } from "@angular/core";
import { CreateUserComponent } from './components/create-user/create-user.component';
import { SearchUserComponent } from './components/search-user/search-user.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UsersRoutingModule } from './user-routing.module';
import { UserService } from './services/user.service';
import { HttpClientModule } from '@angular/common/http';
import {MatTableModule} from '@angular/material/table';
import { MatPaginatorModule, MatDialogModule } from '@angular/material';
import {MatSortModule} from '@angular/material/sort';
import {MatInputModule} from '@angular/material/input';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RouterModule } from '@angular/router';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import { SharedModule } from '../shared/shared.module';
import { ConfirmationDialogComponent } from '../shared/components/confirmation-dialog/confirmation-dialog.component';
import { ConfirmationSnackbarComponent } from '../shared/components/confirmation-snackbar/confirmation-snackbar.component';
@NgModule({
    declarations:[
        CreateUserComponent, 
        SearchUserComponent, 
        EditUserComponent        
        ],
    exports:[
        CreateUserComponent, 
        SearchUserComponent],
    imports:[ 
        CommonModule,
        SharedModule,
        FormsModule,
        UsersRoutingModule,
        HttpClientModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatInputModule,
        MatTooltipModule,
        MatDialogModule,
        FontAwesomeModule,
        RouterModule],
    providers:[UserService],
    entryComponents: [ConfirmationDialogComponent, ConfirmationSnackbarComponent]
})
export class UserModule{
 

}