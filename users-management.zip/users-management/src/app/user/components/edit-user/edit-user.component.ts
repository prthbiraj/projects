import { Component, OnInit } from '@angular/core';
import { User } from '../../model/user.model';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  public userModel:User = new User(); 
  public userId;
  constructor(private route: ActivatedRoute,
    private userService:UserService) { }

  ngOnInit() {   
    this.route.params.subscribe(params => this.userId = params.userId); 
    this.userModel.name = this.userId;

    this.userService.getUserById(this.userId).subscribe(user => {
      console.log(user)
    });

  }

}
