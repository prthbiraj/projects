import { Component, OnInit } from '@angular/core';
import { User } from '../../model/user.model';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  public userModel:User = new User();

  constructor() { }

  ngOnInit() {
  }

  submitForm(){
    console.log("User ", this.userModel);
  }
}
