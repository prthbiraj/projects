import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from '../../services/user.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table'
import {MatSort} from '@angular/material/sort';
import { faCoffee, faUserEdit, faUserSlash, faTrash } from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';
import { DialogUtilService } from 'src/app/shared/services/dialog-util.service';
import { SnackbarUtilService } from 'src/app/shared/services/snackbar-util.service';
import { ELEMENT_DATA, User } from '../../model/user.model';

@Component({
  selector: 'app-search-user',
  templateUrl: './search-user.component.html',
  styleUrls: ['./search-user.component.css']
})
export class SearchUserComponent implements OnInit {

  faCoffee = faCoffee;
  faUserEdit=faUserEdit
  faUserSlash=faUserSlash;
  faTrash= faTrash;
  displayedColumns: string[] = ['name','eamil', 'contactNo', 'address','action']; 
  dataSource = new MatTableDataSource<User>(ELEMENT_DATA);
  
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor(private userService:UserService, 
    private router:Router,
    private dialogUtilService:DialogUtilService,
    private snackbarUtilService:SnackbarUtilService) {   
   }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.userService.getUsers().subscribe(data =>{
        console.log(data);
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  addUser(){
    let data = { type: "info", title: "Confirmation", msg: "Do you want to add user?", okButtonText: "Ok" };
    let config = {width : "600px",disableClose : true,autoFocus: true, data:data}
    let dialogRef = this.dialogUtilService.showDialog(config);
    dialogRef.afterClosed().subscribe(result => {      
      if (result) {
        this.router.navigate([`/users/new`]);
      }
    });
  }

  deleteUser(){
    let data = { type: "danger", title: "Confirmation", msg: "Do you want to delete user?", okButtonText: "Ok" };
    let config = {width : "600px",disableClose : true,autoFocus: true, data:data}
    let dialogRef = this.dialogUtilService.showDialog(config);
    dialogRef.afterClosed().subscribe(result => {      
      if (result) {  
        let barData = {message:'User deleted successfully!',action:'close'}      
        let barConfig = {duration: 2000, verticalPosition:'bottom', horizontalPosition:'center', data:barData}
        this.snackbarUtilService.openSnackBar(barConfig);
      }
    });
  }

  disableUser(){
    let data = { type: "warning", title: "Confirmation", msg: "Do you want to deactivate user?", okButtonText: "Ok" };
    let config = {width : "600px",disableClose : true,autoFocus: true, data:data}
    let dialogRef = this.dialogUtilService.showDialog(config);
    dialogRef.afterClosed().subscribe(result => {      
      if (result) {
        let barData = {message:'User deactivate successfully!',action:'close'}
        let barConfig = {duration: 2000, verticalPosition:'bottom', horizontalPosition:'center', data:barData}
        this.snackbarUtilService.openSnackBar(barConfig);
      }
    });
  }
}

