import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})


export class ContactComponent implements OnInit {
 public contactModel: ContactModel = new ContactModel();
  constructor() { }

  ngOnInit() {
  }

  submitForm(){
    console.log("contactModel ", this.contactModel);
  }
}

class ContactModel{
  name:string;
  email:string;
  massage:string;
}