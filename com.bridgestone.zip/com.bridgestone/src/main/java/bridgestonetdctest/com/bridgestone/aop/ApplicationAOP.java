package bridgestonetdctest.com.bridgestone.aop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ApplicationAOP {

	@Before("execution(* bridgestonetdctest.com.bridgestone.*.*.*(..))")
	public void logginStart() {
		System.out.println("method started");
	}
	
	@After("execution(* bridgestonetdctest.com.bridgestone.*.*.*(..))")
	public void logginEnd() {
		System.out.println("method ended");
	}
	
	@AfterThrowing(pointcut = "execution(* bridgestonetdctest.com.bridgestone.*.*.*(..)))", throwing = "e")
	public void logginExpection() {
		System.out.println("Exception occured");
	}
}
