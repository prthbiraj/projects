package bridgestonetdctest.com.bridgestone.user.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import bridgestonetdctest.com.bridgestone.user.model.UserEntity;
import bridgestonetdctest.com.bridgestone.user.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping("/all")
	public ResponseEntity<List<UserEntity>> findAll() {
		return new ResponseEntity<>(userService.findUsers(), HttpStatus.OK);
	}

	@GetMapping("/view")
	public ResponseEntity<UserEntity> getUser(@RequestParam Long id) {
		return new ResponseEntity<>(userService.findById(id), HttpStatus.OK);
	}

	@PostMapping("/create")
	public ResponseEntity<UserEntity> saveUser(@RequestBody UserEntity userEntity) {
		return new ResponseEntity<>(userService.saveUserEntity(userEntity), HttpStatus.OK);
	}

	@PutMapping("/update")
	public ResponseEntity<UserEntity> updateUser(@RequestBody UserEntity userEntity, @RequestParam Long id) {
		return new ResponseEntity<>(userService.updateUserEntity(id, userEntity), HttpStatus.OK);
	}

	@DeleteMapping("/delete")
	public ResponseEntity<String> deleteUser(@RequestParam Long id) {
		return new ResponseEntity<>(userService.deletUserEntity(id), HttpStatus.OK);
	}

}
