package bridgestonetdctest.com.bridgestone.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import bridgestonetdctest.com.bridgestone.user.model.UserEntity;
import bridgestonetdctest.com.bridgestone.user.service.UserService;

@Component
public class ApplicationInterceptor implements HandlerInterceptor{

	@Autowired
	private UserService userService;
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		String emailId = request.getHeader("user-email-id");
		
		UserEntity userEntity =  userService.findByEmailId(emailId);
		
		if(null != userEntity) {
			return true;
		}			
		
		return false;
	}
	
	
}
