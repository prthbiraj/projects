package bridgestonetdctest.com.bridgestone.exception;

public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = 1L;	

	public ApplicationException(String errorMassage) {
		super(errorMassage);
	}

}
