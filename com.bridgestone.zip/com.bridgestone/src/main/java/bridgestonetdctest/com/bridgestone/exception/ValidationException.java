package bridgestonetdctest.com.bridgestone.exception;

public class ValidationException extends ApplicationException{


	private static final long serialVersionUID = 1L;

	public ValidationException(String errorMassage) {
		super(errorMassage);
	}

}
