package bridgestonetdctest.com.bridgestone.user.service;

import java.util.List;
import java.util.Optional;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bridgestonetdctest.com.bridgestone.exception.RecordNotFoundException;
import bridgestonetdctest.com.bridgestone.user.model.UserEntity;
import bridgestonetdctest.com.bridgestone.user.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public List<UserEntity> findUsers() {
		return userRepository.findAll();
	}

	public UserEntity findById(Long id) {
		Optional<UserEntity> result = userRepository.findById(id);
		if (result.isPresent()) {
			return result.get();
		} else {
			throw new RecordNotFoundException("Record is not exist in database");
		}
	}

	public UserEntity findByEmailId(String emailId) {
		Optional<UserEntity> result = userRepository.findByEmailId(emailId);
		if (result.isPresent()) {
			return result.get();
		} else {
			return null;
		}
	}

	public UserEntity saveUserEntity(UserEntity userEntity) {
		return userRepository.save(userEntity);
	}

	public UserEntity updateUserEntity(Long id, UserEntity userEntity) {
		Optional<UserEntity> result = userRepository.findById(id);
		if (result.isPresent()) {
			UserEntity tempUserEntity = result.get();
			tempUserEntity.setName(userEntity.getName());
			tempUserEntity.setLastName(userEntity.getLastName());
			tempUserEntity.setEmailId(userEntity.getEmailId());
			tempUserEntity.setAddress(userEntity.getAddress());
			return userRepository.save(tempUserEntity);
		} else {
			throw new RecordNotFoundException("Record is not exist in database");
		}
	}

	public String deletUserEntity(Long id) {
		Optional<UserEntity> result = userRepository.findById(id);
		if (result.isPresent()) {
			userRepository.delete(result.get());
		} else {
			throw new RecordNotFoundException("Record is not exist in database");
		}
		return "User has been deleted successfully";
	}
}
