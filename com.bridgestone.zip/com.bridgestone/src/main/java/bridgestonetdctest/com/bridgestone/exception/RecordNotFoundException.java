package bridgestonetdctest.com.bridgestone.exception;

public class RecordNotFoundException extends ApplicationException{

	private static final long serialVersionUID = 1L;

	public RecordNotFoundException(String errorMassage) {
		super(errorMassage);		
	}

}
